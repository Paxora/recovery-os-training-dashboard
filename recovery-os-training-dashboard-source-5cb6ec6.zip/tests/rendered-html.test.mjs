import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

test("includes the required Recovery OS execution and record surfaces", async () => {
  const [page, route, schema, hosting] = await Promise.all([
    readFile(new URL("app/page.tsx", root), "utf8"),
    readFile(new URL("app/api/training-sessions/route.ts", root), "utf8"),
    readFile(new URL("db/schema.ts", root), "utf8"),
    readFile(new URL(".openai/hosting.json", root), "utf8"),
  ]);

  for (const required of [
    "今日训练卡",
    "set-row",
    "扫描 Apple Watch 记录",
    "本地识别 · 免费",
    "确认并保存",
    "训练历史",
    "胸痛、胸闷、头晕或异常气短",
  ]) {
    assert.match(page, new RegExp(required, "i"));
  }

  assert.match(page, /BV1m2421L7tw/);
  assert.match(page, /BV1r341127uy/);
  assert.match(page, /tesseract\.js/);
  assert.doesNotMatch(page, /系统判断/);
  assert.match(route, /trainingSessions/);
  assert.match(route, /exerciseRecords/);
  assert.match(schema, /training_sessions/);
  assert.match(schema, /exercise_records/);
  assert.equal(JSON.parse(hosting).d1, "DB");
});
