import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const trainingSessions = sqliteTable(
  "training_sessions",
  {
    id: text("id").primaryKey(),
    sessionDate: text("session_date").notNull(),
    sessionLabel: text("session_label").notNull(),
    completedCount: integer("completed_count").notNull().default(0),
    totalCount: integer("total_count").notNull().default(0),
    energy: integer("energy"),
    bodyFeedback: text("body_feedback").notNull().default(""),
    notes: text("notes").notNull().default(""),
    watchDuration: text("watch_duration").notNull().default(""),
    watchActiveCalories: integer("watch_active_calories"),
    watchTotalCalories: integer("watch_total_calories"),
    watchAverageHeartRate: integer("watch_average_heart_rate"),
    watchSource: text("watch_source").notNull().default("manual"),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    index("training_sessions_date_idx").on(table.sessionDate),
    index("training_sessions_created_idx").on(table.createdAt),
  ],
);

export const exerciseRecords = sqliteTable(
  "exercise_records",
  {
    id: text("id").primaryKey(),
    sessionId: text("session_id")
      .notNull()
      .references(() => trainingSessions.id, { onDelete: "cascade" }),
    exerciseKey: text("exercise_key").notNull(),
    position: integer("position").notNull(),
    name: text("name").notNull(),
    english: text("english").notNull().default(""),
    prescription: text("prescription").notNull().default(""),
    rest: text("rest").notNull().default(""),
    completed: integer("completed", { mode: "boolean" })
      .notNull()
      .default(false),
    setsJson: text("sets_json").notNull().default("[]"),
    metricsJson: text("metrics_json").notNull().default("{}"),
  },
  (table) => [
    index("exercise_records_session_idx").on(table.sessionId),
    index("exercise_records_key_idx").on(table.exerciseKey),
  ],
);
