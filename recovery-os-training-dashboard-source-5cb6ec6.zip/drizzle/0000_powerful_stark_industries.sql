CREATE TABLE `exercise_records` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`exercise_key` text NOT NULL,
	`position` integer NOT NULL,
	`name` text NOT NULL,
	`english` text DEFAULT '' NOT NULL,
	`prescription` text DEFAULT '' NOT NULL,
	`rest` text DEFAULT '' NOT NULL,
	`completed` integer DEFAULT false NOT NULL,
	`sets_json` text DEFAULT '[]' NOT NULL,
	`metrics_json` text DEFAULT '{}' NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `training_sessions`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `exercise_records_session_idx` ON `exercise_records` (`session_id`);--> statement-breakpoint
CREATE INDEX `exercise_records_key_idx` ON `exercise_records` (`exercise_key`);--> statement-breakpoint
CREATE TABLE `training_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`session_date` text NOT NULL,
	`session_label` text NOT NULL,
	`completed_count` integer DEFAULT 0 NOT NULL,
	`total_count` integer DEFAULT 0 NOT NULL,
	`energy` integer,
	`body_feedback` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`watch_duration` text DEFAULT '' NOT NULL,
	`watch_active_calories` integer,
	`watch_total_calories` integer,
	`watch_average_heart_rate` integer,
	`watch_source` text DEFAULT 'manual' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `training_sessions_date_idx` ON `training_sessions` (`session_date`);--> statement-breakpoint
CREATE INDEX `training_sessions_created_idx` ON `training_sessions` (`created_at`);