import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://recovery-os-training-dashboard.panaker.chatgpt.site/"),
  title: "Recovery OS · Training Dashboard",
  description: "手机优先的 Recovery OS 训练现场执行、记录与历史 Dashboard。",
  openGraph: {
    title: "Recovery OS · Training Dashboard",
    description: "手机优先的训练现场执行、Apple Watch 识别与历史记录。",
    images: [
      "/recovery-os-training-dashboard-og.png",
    ],
  },
  icons: {
    icon: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
