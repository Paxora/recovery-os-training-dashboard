"use client";

import { ChangeEvent, useEffect, useMemo, useRef, useState } from "react";

type SetEntry = {
  weight: string;
  reps: string;
};

type Exercise = {
  id: string;
  order: string;
  name: string;
  english: string;
  prescription: string;
  rest: string;
  cue: string;
  setCount?: number;
  video?: string;
  isNew?: boolean;
  optional?: boolean;
  metrics?: Array<{ key: string; label: string; unit: string }>;
};

type TrainingState = {
  completed: Record<string, boolean>;
  sets: Record<string, SetEntry[]>;
  metrics: Record<string, Record<string, string>>;
  energy: string;
  bodyFeedback: string;
  notes: string;
  watch: {
    duration: string;
    activeCalories: string;
    totalCalories: string;
    averageHeartRate: string;
    source: "manual" | "ocr";
  };
};

type SavedExercise = {
  id: string;
  exerciseKey: string;
  name: string;
  english: string;
  prescription: string;
  completed: boolean;
  sets: SetEntry[];
  metrics: Record<string, string>;
};

type SavedSession = {
  id: string;
  sessionDate: string;
  sessionLabel: string;
  completedCount: number;
  totalCount: number;
  energy: number | null;
  bodyFeedback: string;
  notes: string;
  watchDuration: string;
  watchActiveCalories: number | null;
  watchTotalCalories: number | null;
  watchAverageHeartRate: number | null;
  watchSource: string;
  exercises: SavedExercise[];
};

const exercises: Exercise[] = [
  {
    id: "warmup",
    order: "01",
    name: "跑步机快走",
    english: "Treadmill",
    prescription: "8–10 分钟",
    rest: "—",
    cue: "身体微热即可，不需要跑。",
    metrics: [
      { key: "duration", label: "实际时长", unit: "分钟" },
      { key: "distance", label: "实际距离", unit: "km" },
    ],
  },
  {
    id: "row",
    order: "02",
    name: "坐姿器械划船",
    english: "Seated Row",
    prescription: "2–3 × 10–12",
    rest: "90 秒",
    cue: "胸口打开，肘向后拉，不耸肩。",
    setCount: 3,
    isNew: true,
    video: "https://www.bilibili.com/video/BV1m2421L7tw/",
  },
  {
    id: "shoulder",
    order: "03",
    name: "坐姿推肩机",
    english: "Shoulder Press",
    prescription: "2 × 10–12",
    rest: "90 秒",
    cue: "背贴靠垫，不塌腰，手肘不锁死。",
    setCount: 2,
    isNew: true,
    video: "https://www.bilibili.com/video/BV1r341127uy/",
  },
  {
    id: "pulldown",
    order: "04",
    name: "高位下拉",
    english: "Lat Pulldown",
    prescription: "2 × 10–12",
    rest: "90 秒",
    cue: "拉到上胸，身体不要大幅后仰。",
    setCount: 2,
  },
  {
    id: "chest",
    order: "05",
    name: "坐姿推胸",
    english: "Chest Press",
    prescription: "2 × 10–12",
    rest: "90 秒",
    cue: "肩膀向后下沉，回程保持控制。",
    setCount: 2,
  },
  {
    id: "legpress",
    order: "06",
    name: "腿举",
    english: "Leg Press",
    prescription: "2 × 10–12",
    rest: "90 秒",
    cue: "仅在腿部无明显酸痛时做；膝盖与脚尖同向。",
    setCount: 2,
    optional: true,
  },
  {
    id: "cooldown",
    order: "07",
    name: "跑步机放松",
    english: "Cool-down Walk",
    prescription: "8–10 分钟",
    rest: "—",
    cue: "轻松走路，让呼吸逐渐恢复。",
    metrics: [
      { key: "duration", label: "实际时长", unit: "分钟" },
      { key: "distance", label: "实际距离", unit: "km" },
    ],
  },
];

const DRAFT_KEY = "recovery-os-training-dashboard-v2-draft";
const LEGACY_KEY = "recovery-os-training-dashboard-v1";

function createEmptyState(): TrainingState {
  return {
    completed: {},
    sets: Object.fromEntries(
      exercises
        .filter((exercise) => exercise.setCount)
        .map((exercise) => [
          exercise.id,
          Array.from({ length: exercise.setCount ?? 0 }, () => ({
            weight: "",
            reps: "",
          })),
        ]),
    ),
    metrics: Object.fromEntries(
      exercises
        .filter((exercise) => exercise.metrics)
        .map((exercise) => [
          exercise.id,
          Object.fromEntries((exercise.metrics ?? []).map((metric) => [metric.key, ""])),
        ]),
    ),
    energy: "",
    bodyFeedback: "",
    notes: "",
    watch: {
      duration: "",
      activeCalories: "",
      totalCalories: "",
      averageHeartRate: "",
      source: "manual",
    },
  };
}

function localDateString() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function displayDate(value: string) {
  const [, month, day] = value.split("-");
  return `${Number(month)}月${Number(day)}日`;
}

function metricSummary(metrics: Record<string, string>) {
  const units: Record<string, string> = {
    duration: "分钟",
    distance: "km",
  };
  return Object.entries(metrics)
    .filter(([, value]) => value)
    .map(([key, value]) => `${value} ${units[key] ?? ""}`.trim())
    .join(" · ");
}

function firstMatch(text: string, patterns: RegExp[]) {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match?.[1]) return match[1].replace(/\s/g, "");
  }
  return "";
}

function parseWatchText(text: string) {
  const normalized = text
    .replace(/[，,]/g, " ")
    .replace(/[：﹕]/g, ":")
    .replace(/\s+/g, " ");
  return {
    duration: firstMatch(normalized, [
      /(?:训练时长|总时间|总计时间|时间)\D{0,16}(\d{1,2}:\d{2}(?::\d{2})?)/i,
      /(\d{1,2}:\d{2}:\d{2})/,
    ]),
    activeCalories: firstMatch(normalized, [
      /(?:活动热量|活动能量|活动卡路里)\D{0,12}(\d{1,4})/i,
    ]),
    totalCalories: firstMatch(normalized, [
      /(?:总热量|总能量|总卡路里)\D{0,12}(\d{1,4})/i,
    ]),
    averageHeartRate: firstMatch(normalized, [
      /(?:平均心率|平均心律)\D{0,12}(\d{2,3})/i,
    ]),
  };
}

export default function Home() {
  const [state, setState] = useState<TrainingState>(createEmptyState);
  const [loaded, setLoaded] = useState(false);
  const [view, setView] = useState<"workout" | "record" | "history">("workout");
  const [sessions, setSessions] = useState<SavedSession[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState("");
  const [expandedSession, setExpandedSession] = useState("");
  const [scanStatus, setScanStatus] = useState("");
  const [scanProgress, setScanProgress] = useState(0);
  const [scanPreview, setScanPreview] = useState("");
  const [saveStatus, setSaveStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(DRAFT_KEY);
      if (saved) {
        setState({ ...createEmptyState(), ...(JSON.parse(saved) as TrainingState) });
      } else {
        const legacy = localStorage.getItem(LEGACY_KEY);
        if (legacy) {
          const old = JSON.parse(legacy) as {
            completed?: Record<string, boolean>;
            weights?: Record<string, string>;
            energy?: string;
            soreness?: string;
            feedback?: string;
            watch?: Partial<TrainingState["watch"]>;
          };
          const migrated = createEmptyState();
          migrated.completed = old.completed ?? {};
          migrated.energy = old.energy?.match(/^[1-5]/)?.[0] ?? "";
          migrated.bodyFeedback = old.soreness ?? "";
          migrated.notes = old.feedback ?? "";
          migrated.watch = { ...migrated.watch, ...(old.watch ?? {}) };
          for (const [exerciseId, weight] of Object.entries(old.weights ?? {})) {
            if (migrated.sets[exerciseId]?.[0]) migrated.sets[exerciseId][0].weight = weight;
          }
          setState(migrated);
        }
      }
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (loaded) localStorage.setItem(DRAFT_KEY, JSON.stringify(state));
  }, [loaded, state]);

  const completedCount = useMemo(
    () => exercises.filter((exercise) => state.completed[exercise.id]).length,
    [state.completed],
  );

  const fetchHistory = async () => {
    setHistoryLoading(true);
    setHistoryError("");
    try {
      const response = await fetch("/api/training-sessions", { cache: "no-store" });
      const data = (await response.json()) as { sessions?: SavedSession[]; error?: string };
      if (!response.ok) throw new Error(data.error || "训练历史读取失败。");
      setSessions(data.sessions ?? []);
      if (!expandedSession && data.sessions?.[0]) setExpandedSession(data.sessions[0].id);
    } catch (error) {
      setHistoryError(error instanceof Error ? error.message : "训练历史读取失败。");
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    void fetchHistory();
  }, []);

  const updateSet = (exerciseId: string, index: number, key: keyof SetEntry, value: string) => {
    setState((current) => ({
      ...current,
      sets: {
        ...current.sets,
        [exerciseId]: current.sets[exerciseId].map((set, setIndex) =>
          setIndex === index ? { ...set, [key]: value } : set,
        ),
      },
    }));
  };

  const updateMetric = (exerciseId: string, key: string, value: string) => {
    setState((current) => ({
      ...current,
      metrics: {
        ...current.metrics,
        [exerciseId]: { ...current.metrics[exerciseId], [key]: value },
      },
    }));
  };

  const resetDraft = () => {
    if (!window.confirm("清空本次训练的完成状态和现场记录？")) return;
    const empty = createEmptyState();
    setState(empty);
    setScanPreview("");
    setScanStatus("");
    setSaveStatus("");
    localStorage.setItem(DRAFT_KEY, JSON.stringify(empty));
  };

  const handleWatchImage = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (scanPreview) URL.revokeObjectURL(scanPreview);
    setScanPreview(URL.createObjectURL(file));
    setScanStatus("正在本地识别图片…");
    setScanProgress(0);

    try {
      const { createWorker, OEM } = await import("tesseract.js");
      const worker = await createWorker(["chi_sim", "eng"], OEM.LSTM_ONLY, {
        logger: (message) => {
          if (typeof message.progress === "number") {
            setScanProgress(Math.round(message.progress * 100));
          }
        },
      });
      const result = await worker.recognize(file);
      await worker.terminate();
      const parsed = parseWatchText(result.data.text);
      const found = Object.values(parsed).filter(Boolean).length;
      setState((current) => ({
        ...current,
        watch: {
          ...current.watch,
          ...Object.fromEntries(Object.entries(parsed).filter(([, value]) => value)),
          source: "ocr",
        },
      }));
      setScanStatus(
        found
          ? `已识别 ${found} 项，请检查后确认。`
          : "没有可靠识别到数据，请重新拍摄或手动填写。",
      );
    } catch {
      setScanStatus("本地识别未完成，请重新拍摄或手动填写。");
    } finally {
      event.target.value = "";
    }
  };

  const saveSession = async () => {
    setSaving(true);
    setSaveStatus("");
    try {
      const response = await fetch("/api/training-sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionDate: localDateString(),
          sessionLabel: "第 2 次入馆",
          energy: state.energy ? Number(state.energy) : null,
          bodyFeedback: state.bodyFeedback,
          notes: state.notes,
          watch: state.watch,
          exercises: exercises.map((exercise) => ({
            id: exercise.id,
            name: exercise.name,
            english: exercise.english,
            prescription: exercise.prescription,
            rest: exercise.rest,
            completed: Boolean(state.completed[exercise.id]),
            sets: state.sets[exercise.id] ?? [],
            metrics: state.metrics[exercise.id] ?? {},
          })),
        }),
      });
      const data = (await response.json()) as { id?: string; error?: string };
      if (!response.ok) throw new Error(data.error || "训练记录保存失败。");

      const empty = createEmptyState();
      setState(empty);
      localStorage.setItem(DRAFT_KEY, JSON.stringify(empty));
      setSaveStatus("训练记录已保存。");
      setView("history");
      await fetchHistory();
    } catch (error) {
      setSaveStatus(error instanceof Error ? error.message : "训练记录保存失败。");
    } finally {
      setSaving(false);
    }
  };

  const openHistory = () => {
    setView("history");
    void fetchHistory();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <main className="app-shell">
      {view === "workout" && (
        <>
          <header className="page-header">
            <div>
              <p className="eyebrow">TODAY&apos;S WORKOUT</p>
              <h1>今日训练卡</h1>
            </div>
            <button className="outline-button" type="button" onClick={openHistory}>
              历史
            </button>
          </header>

          <section className="progress-card" aria-label="训练进度">
            <div>
              <span>今日训练 · Session 02</span>
              <strong>{completedCount} / {exercises.length}</strong>
            </div>
            <div className="progress-track">
              <span style={{ width: `${(completedCount / exercises.length) * 100}%` }} />
            </div>
          </section>

          <div className="exercise-list">
            {exercises.map((exercise) => {
              const done = Boolean(state.completed[exercise.id]);
              return (
                <article className={`exercise-card ${done ? "is-done" : ""}`} key={exercise.id}>
                  <button
                    type="button"
                    className="order-button"
                    aria-pressed={done}
                    aria-label={`${done ? "取消完成" : "标记完成"} ${exercise.name}`}
                    onClick={() =>
                      setState((current) => ({
                        ...current,
                        completed: { ...current.completed, [exercise.id]: !done },
                      }))
                    }
                  >
                    {done ? "✓ 已完成" : exercise.order}
                  </button>

                  <div className="exercise-title">
                    <div>
                      <div className="badges">
                        {exercise.isNew && <span className="badge">新动作</span>}
                        {exercise.optional && <span className="badge neutral">视酸痛决定</span>}
                      </div>
                      <h2>{exercise.name}</h2>
                      <p>{exercise.english}</p>
                    </div>
                    {exercise.video && (
                      <a href={exercise.video} target="_blank" rel="noreferrer">
                        中文教学视频 ↗
                      </a>
                    )}
                  </div>

                  <div className="prescription-grid">
                    <div>
                      <span>训练量</span>
                      <strong>{exercise.prescription}</strong>
                    </div>
                    <div>
                      <span>组间休息</span>
                      <strong>{exercise.rest}</strong>
                    </div>
                  </div>

                  {exercise.setCount && (
                    <div className="set-table">
                      <div className="set-head">
                        <span />
                        <span>重量</span>
                        <span>次数</span>
                      </div>
                      {(state.sets[exercise.id] ?? []).map((set, index) => (
                        <div className="set-row" key={`${exercise.id}-${index}`}>
                          <strong>第 {index + 1} 组</strong>
                          <label>
                            <input
                              value={set.weight}
                              inputMode="decimal"
                              placeholder="—"
                              aria-label={`${exercise.name}第${index + 1}组重量`}
                              onChange={(event) =>
                                updateSet(exercise.id, index, "weight", event.target.value)
                              }
                            />
                            <small>kg</small>
                          </label>
                          <input
                            value={set.reps}
                            inputMode="numeric"
                            placeholder="—"
                            aria-label={`${exercise.name}第${index + 1}组次数`}
                            onChange={(event) =>
                              updateSet(exercise.id, index, "reps", event.target.value)
                            }
                          />
                        </div>
                      ))}
                    </div>
                  )}

                  {exercise.metrics && (
                    <div className="metric-entry-grid">
                      {exercise.metrics.map((metric) => (
                        <label key={metric.key}>
                          <span>{metric.label}</span>
                          <div>
                            <input
                              inputMode="decimal"
                              value={state.metrics[exercise.id]?.[metric.key] ?? ""}
                              placeholder="—"
                              onChange={(event) =>
                                updateMetric(exercise.id, metric.key, event.target.value)
                              }
                            />
                            <small>{metric.unit}</small>
                          </div>
                        </label>
                      ))}
                    </div>
                  )}

                  <p className="cue">{exercise.cue}</p>
                </article>
              );
            })}
          </div>

          <aside className="safety-strip">
            <strong>!</strong>
            <span>胸痛、胸闷、头晕或异常气短，立即停止训练。</span>
          </aside>

          <div className="sticky-actions">
            <button className="secondary-button" type="button" onClick={resetDraft}>
              重置本次
            </button>
            <button
              className="primary-button"
              type="button"
              onClick={() => {
                setView("record");
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
            >
              结束并记录
            </button>
          </div>
        </>
      )}

      {view === "record" && (
        <>
          <header className="page-header record-header">
            <div>
              <button className="back-button" type="button" onClick={() => setView("workout")}>
                ← 返回训练卡
              </button>
              <p className="eyebrow">WORKOUT RECORD</p>
              <h1>训练记录</h1>
            </div>
          </header>

          <section className="scan-card">
            <input
              ref={fileInputRef}
              className="visually-hidden"
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleWatchImage}
            />
            <button
              className="scan-button"
              type="button"
              onClick={() => fileInputRef.current?.click()}
            >
              <span className="camera-icon">◉</span>
              <strong>扫描 Apple Watch 记录</strong>
              <small>拍摄手表或选择训练总结截图</small>
            </button>
            <span className="local-badge">● 本地识别 · 免费</span>
            {scanStatus && (
              <p className="scan-status">
                {scanStatus}
                {scanProgress > 0 && scanProgress < 100 ? ` ${scanProgress}%` : ""}
              </p>
            )}
          </section>

          <section className="record-card">
            <div className="record-card-title">
              <div>
                <p className="eyebrow">APPLE WATCH</p>
                <h2>识别结果</h2>
              </div>
              {scanPreview && <img src={scanPreview} alt="待确认的 Apple Watch 记录" />}
            </div>
            <div className="watch-fields">
              {[
                ["duration", "训练时长", "时:分:秒"],
                ["activeCalories", "活动热量", "千卡"],
                ["totalCalories", "总热量", "千卡"],
                ["averageHeartRate", "平均心率", "次/分"],
              ].map(([key, label, unit]) => (
                <label key={key}>
                  <span>{label}</span>
                  <div>
                    <input
                      value={state.watch[key as keyof Omit<TrainingState["watch"], "source">]}
                      placeholder="—"
                      inputMode={key === "duration" ? "text" : "numeric"}
                      onChange={(event) =>
                        setState((current) => ({
                          ...current,
                          watch: {
                            ...current.watch,
                            [key]: event.target.value,
                            source: current.watch.source === "ocr" ? "ocr" : "manual",
                          },
                        }))
                      }
                    />
                    <small>{unit}</small>
                  </div>
                </label>
              ))}
            </div>
            <p className="confirm-note">识别结果可以修改；确认无误后再保存。</p>
          </section>

          <section className="record-card">
            <p className="eyebrow">POST-WORKOUT</p>
            <h2>现场反馈</h2>
            <div className="feedback-fields">
              <label>
                <span>Energy</span>
                <select
                  value={state.energy}
                  onChange={(event) =>
                    setState((current) => ({ ...current, energy: event.target.value }))
                  }
                >
                  <option value="">未记录</option>
                  <option value="1">1 / 5 · 极低</option>
                  <option value="2">2 / 5 · 较低</option>
                  <option value="3">3 / 5 · 一般</option>
                  <option value="4">4 / 5 · 较好</option>
                  <option value="5">5 / 5 · 很好</option>
                </select>
              </label>
              <label>
                <span>身体反馈</span>
                <select
                  value={state.bodyFeedback}
                  onChange={(event) =>
                    setState((current) => ({ ...current, bodyFeedback: event.target.value }))
                  }
                >
                  <option value="">未记录</option>
                  <option>无异常</option>
                  <option>轻微酸痛，不影响活动</option>
                  <option>明显酸痛或疲劳</option>
                  <option>出现胸闷、头晕或异常气短</option>
                </select>
              </label>
              <label>
                <span>备注</span>
                <textarea
                  value={state.notes}
                  maxLength={500}
                  rows={4}
                  placeholder="只记录本次训练现场事实。"
                  onChange={(event) =>
                    setState((current) => ({ ...current, notes: event.target.value }))
                  }
                />
              </label>
            </div>
          </section>

          {saveStatus && <p className="save-status">{saveStatus}</p>}
          <button className="primary-button full" type="button" disabled={saving} onClick={saveSession}>
            {saving ? "正在保存…" : "确认并保存"}
          </button>
        </>
      )}

      {view === "history" && (
        <>
          <header className="page-header history-header">
            <div>
              <button className="back-button" type="button" onClick={() => setView("workout")}>
                ← 今日训练
              </button>
              <p className="eyebrow">TRAINING HISTORY</p>
              <h1>训练历史</h1>
            </div>
          </header>

          <section className="history-summary">
            <span>已保存训练</span>
            <strong>{sessions.length} 次</strong>
          </section>

          {historyLoading && <div className="empty-state">正在读取训练历史…</div>}
          {historyError && <div className="empty-state error">{historyError}</div>}
          {!historyLoading && !historyError && sessions.length === 0 && (
            <div className="empty-state">完成训练并保存后，记录会显示在这里。</div>
          )}

          <div className="history-list">
            {sessions.map((session) => {
              const expanded = expandedSession === session.id;
              const percentage = session.totalCount
                ? Math.round((session.completedCount / session.totalCount) * 100)
                : 0;
              return (
                <article className="history-card" key={session.id}>
                  <button
                    type="button"
                    className="history-toggle"
                    onClick={() => setExpandedSession(expanded ? "" : session.id)}
                    aria-expanded={expanded}
                  >
                    <div>
                      <h2>{displayDate(session.sessionDate)}</h2>
                      <span>{session.sessionLabel}</span>
                    </div>
                    <div className="history-result">
                      <strong>{percentage}% 完成</strong>
                      <span>{expanded ? "⌃" : "⌄"}</span>
                    </div>
                  </button>
                  <div className="history-meta">
                    <span>◷ {session.watchDuration || "时长未记录"}</span>
                    <span>Energy {session.energy ? `${session.energy} / 5` : "未记录"}</span>
                  </div>
                  {expanded && (
                    <div className="history-detail">
                      {session.exercises.map((exercise) => {
                        const recordedSets = exercise.sets.filter(
                          (set) => set.weight || set.reps,
                        );
                        const summary = recordedSets.length
                          ? recordedSets
                              .map((set) =>
                                [set.weight ? `${set.weight} kg` : "", set.reps ? `${set.reps} 次` : ""]
                                  .filter(Boolean)
                                  .join(" × "),
                              )
                              .join(" · ")
                          : metricSummary(exercise.metrics) || exercise.prescription;
                        return (
                          <div className="history-exercise" key={exercise.id}>
                            <span>{exercise.name}</span>
                            <strong>{summary || "未记录"}</strong>
                          </div>
                        );
                      })}
                      {(session.bodyFeedback || session.notes) && (
                        <div className="history-feedback">
                          {session.bodyFeedback && <p>{session.bodyFeedback}</p>}
                          {session.notes && <p>{session.notes}</p>}
                        </div>
                      )}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        </>
      )}
    </main>
  );
}
