import { desc, inArray } from "drizzle-orm";
import { getDb } from "../../../db";
import { exerciseRecords, trainingSessions } from "../../../db/schema";

export const runtime = "edge";

type SetRecord = {
  weight: string;
  reps: string;
};

type ExercisePayload = {
  id?: string;
  name?: string;
  english?: string;
  prescription?: string;
  rest?: string;
  completed?: boolean;
  sets?: SetRecord[];
  metrics?: Record<string, string>;
};

type SessionPayload = {
  sessionDate?: string;
  sessionLabel?: string;
  energy?: number | null;
  bodyFeedback?: string;
  notes?: string;
  watch?: {
    duration?: string;
    activeCalories?: string;
    totalCalories?: string;
    averageHeartRate?: string;
    source?: string;
  };
  exercises?: ExercisePayload[];
};

const clampText = (value: unknown, max: number) =>
  typeof value === "string" ? value.trim().slice(0, max) : "";

const optionalInteger = (value: unknown) => {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
};

const safeJson = <T,>(value: string, fallback: T): T => {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
};

async function seedConfirmedFirstSession() {
  const db = getDb();
  const sessionId = "confirmed-session-2026-07-24";
  await db
    .insert(trainingSessions)
    .values({
      id: sessionId,
      sessionDate: "2026-07-24",
      sessionLabel: "第 1 次入馆",
      completedCount: 5,
      totalCount: 5,
      bodyFeedback: "训练过程无胸闷、头晕或异常气短；使用轻重量。",
      notes: "Apple Watch 力量训练记录不完整。",
      watchDuration: "记录不完整",
      watchSource: "manual",
    })
    .onConflictDoNothing();

  const confirmedExercises = [
    {
      id: "confirmed-2026-07-24-treadmill",
      exerciseKey: "warmup",
      position: 1,
      name: "跑步机快走",
      english: "Treadmill",
      prescription: "10:01 · 0.91 km",
      setsJson: "[]",
      metricsJson: JSON.stringify({ duration: "10:01", distance: "0.91" }),
    },
    {
      id: "confirmed-2026-07-24-chest",
      exerciseKey: "chest",
      position: 2,
      name: "坐姿推胸",
      english: "Chest Press",
      prescription: "3 组",
      setsJson: JSON.stringify([
        { weight: "", reps: "" },
        { weight: "", reps: "" },
        { weight: "", reps: "" },
      ]),
      metricsJson: "{}",
    },
    {
      id: "confirmed-2026-07-24-pulldown",
      exerciseKey: "pulldown",
      position: 3,
      name: "高位下拉",
      english: "Lat Pulldown",
      prescription: "3 组",
      setsJson: JSON.stringify([
        { weight: "", reps: "" },
        { weight: "", reps: "" },
        { weight: "", reps: "" },
      ]),
      metricsJson: "{}",
    },
    {
      id: "confirmed-2026-07-24-legpress",
      exerciseKey: "legpress",
      position: 4,
      name: "腿举",
      english: "Leg Press",
      prescription: "3 组",
      setsJson: JSON.stringify([
        { weight: "", reps: "" },
        { weight: "", reps: "" },
        { weight: "", reps: "" },
      ]),
      metricsJson: "{}",
    },
    {
      id: "confirmed-2026-07-24-angle-legpress",
      exerciseKey: "angle-legpress",
      position: 5,
      name: "45° 倒蹬机",
      english: "45 Degree Leg Press",
      prescription: "1 组",
      setsJson: JSON.stringify([{ weight: "", reps: "" }]),
      metricsJson: "{}",
    },
  ];

  for (const exercise of confirmedExercises) {
    await db
      .insert(exerciseRecords)
      .values({
        ...exercise,
        sessionId,
        rest: "",
        completed: true,
      })
      .onConflictDoNothing();
  }
}

export async function GET() {
  try {
    await seedConfirmedFirstSession();
    const db = getDb();
    const sessions = await db
      .select()
      .from(trainingSessions)
      .orderBy(desc(trainingSessions.sessionDate), desc(trainingSessions.createdAt))
      .limit(100);

    const sessionIds = sessions.map((session) => session.id);
    const exercises = sessionIds.length
      ? await db
          .select()
          .from(exerciseRecords)
          .where(inArray(exerciseRecords.sessionId, sessionIds))
          .orderBy(exerciseRecords.position)
      : [];

    const grouped = new Map<string, typeof exercises>();
    for (const exercise of exercises) {
      const current = grouped.get(exercise.sessionId) ?? [];
      current.push(exercise);
      grouped.set(exercise.sessionId, current);
    }

    return Response.json({
      sessions: sessions.map((session) => ({
        ...session,
        exercises: (grouped.get(session.id) ?? []).map((exercise) => ({
          ...exercise,
          sets: safeJson<SetRecord[]>(exercise.setsJson, []),
          metrics: safeJson<Record<string, string>>(exercise.metricsJson, {}),
          setsJson: undefined,
          metricsJson: undefined,
        })),
      })),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "训练历史暂时无法读取。";
    return Response.json({ error: message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    await seedConfirmedFirstSession();
    const payload = (await request.json()) as SessionPayload;
    const sessionDate = clampText(payload.sessionDate, 10);
    const sessionLabel = clampText(payload.sessionLabel, 80) || "训练记录";
    const exercises = Array.isArray(payload.exercises) ? payload.exercises.slice(0, 30) : [];

    if (!/^\d{4}-\d{2}-\d{2}$/.test(sessionDate)) {
      return Response.json({ error: "训练日期无效。" }, { status: 400 });
    }
    if (!exercises.length) {
      return Response.json({ error: "训练记录中没有动作。" }, { status: 400 });
    }

    const sessionId = crypto.randomUUID();
    const completedCount = exercises.filter((exercise) => exercise.completed).length;
    const energy =
      typeof payload.energy === "number" && payload.energy >= 1 && payload.energy <= 5
        ? payload.energy
        : null;
    const watch = payload.watch ?? {};
    const db = getDb();

    await db.insert(trainingSessions).values({
      id: sessionId,
      sessionDate,
      sessionLabel,
      completedCount,
      totalCount: exercises.length,
      energy,
      bodyFeedback: clampText(payload.bodyFeedback, 160),
      notes: clampText(payload.notes, 500),
      watchDuration: clampText(watch.duration, 20),
      watchActiveCalories: optionalInteger(watch.activeCalories),
      watchTotalCalories: optionalInteger(watch.totalCalories),
      watchAverageHeartRate: optionalInteger(watch.averageHeartRate),
      watchSource: clampText(watch.source, 24) || "manual",
    });

    for (const [position, exercise] of exercises.entries()) {
      const sets = Array.isArray(exercise.sets)
        ? exercise.sets.slice(0, 12).map((set) => ({
            weight: clampText(set?.weight, 12),
            reps: clampText(set?.reps, 12),
          }))
        : [];
      const metrics =
        exercise.metrics && typeof exercise.metrics === "object"
          ? Object.fromEntries(
              Object.entries(exercise.metrics)
                .slice(0, 12)
                .map(([key, value]) => [clampText(key, 30), clampText(value, 30)]),
            )
          : {};

      await db.insert(exerciseRecords).values({
        id: crypto.randomUUID(),
        sessionId,
        exerciseKey: clampText(exercise.id, 60) || `exercise-${position + 1}`,
        position: position + 1,
        name: clampText(exercise.name, 80) || "未命名动作",
        english: clampText(exercise.english, 80),
        prescription: clampText(exercise.prescription, 80),
        rest: clampText(exercise.rest, 40),
        completed: Boolean(exercise.completed),
        setsJson: JSON.stringify(sets),
        metricsJson: JSON.stringify(metrics),
      });
    }

    return Response.json({ id: sessionId }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "训练记录保存失败。";
    return Response.json({ error: message }, { status: 500 });
  }
}
